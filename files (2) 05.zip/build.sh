#!/bin/sh
# Build all programs of Assignment 5 (Linux, GCC). Run from this directory.
set -e
gcc -std=gnu11 -Wall -Wextra -Wpedantic -Wshadow -o logtool logtool.c eventlog.c
gcc -std=gnu11 -Wall -Wextra -Wpedantic -Wshadow -o t2_file_ops t2_file_ops.c eventlog.c
gcc -std=gnu11 -Wall -Wextra -Wpedantic -Wshadow -o t3_process t3_process.c eventlog.c
gcc -std=gnu11 -Wall -Wextra -Wpedantic -Wshadow -pthread -o t4_threads t4_threads.c eventlog.c
gcc -std=gnu11 -Wall -Wextra -Wpedantic -Wshadow -pthread -o t5_race t5_race.c
gcc -std=gnu11 -Wall -Wextra -Wpedantic -Wshadow -pthread -o t5_condvar t5_condvar.c
gcc -std=gnu11 -Wall -Wextra -Wpedantic -Wshadow -o ipc_producer ipc_producer.c eventlog.c
gcc -std=gnu11 -Wall -Wextra -Wpedantic -Wshadow -o ipc_consumer ipc_consumer.c eventlog.c
gcc -std=gnu11 -Wall -Wextra -Wpedantic -Wshadow -pthread -o t7_process t7_process.c
gcc -std=gnu11 -Wall -Wextra -Wpedantic -Wshadow -o event_server event_server.c eventlog.c net.c
gcc -std=gnu11 -Wall -Wextra -Wpedantic -Wshadow -o event_client event_client.c net.c
gcc -std=gnu11 -Wall -Wextra -Wpedantic -Wshadow -o t9_validate t9_validate.c eventlog.c
gcc -std=gnu11 -Wall -Wextra -Wpedantic -Wshadow -pthread -o campus_monitor campus_monitor.c eventlog.c net.c
gcc -std=gnu11 -Wall -Wextra -Wpedantic -Wshadow -o monitor_server monitor_server.c eventlog.c net.c
