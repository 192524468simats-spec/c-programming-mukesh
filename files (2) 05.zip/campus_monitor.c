/* campus_monitor.c - Task 10: integrated run
 *   file log -> 3 analysis threads (mutex) -> FIFO IPC to ipc_consumer -> TCP to event_server
 * usage: campus_monitor <workdir> [num_events] [port]
 * needs in the current directory: ./ipc_consumer  ./event_server                  */
#define _GNU_SOURCE
#include <arpa/inet.h>
#include <errno.h>
#include <fcntl.h>
#include <netinet/in.h>
#include <pthread.h>
#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <sys/stat.h>
#include <sys/wait.h>
#include <time.h>
#include <unistd.h>
#include "eventlog.h"
#include "net.h"

#define MAX_ALERTS 512
static const char *SRC_NAMES[3] = {"LAB01", "LIB01", "GATE01"};

typedef struct {                                     /* shared state, guarded by lock */
    pthread_mutex_t lock;
    long by_type[NUM_TYPES], by_source[3], processed[3], filtered, dropped;
    Event alerts[MAX_ALERTS];
} Shared;

typedef struct { Shared *sh; const char *path; int which; long rc; } Job;

static void analyse_cb(const Event *e, void *p)
{
    Job *j = p;
    Shared *s = j->sh;
    int i;
    pthread_mutex_lock(&s->lock);                    /* critical section: update shared counters */
    s->processed[j->which]++;
    if (j->which == 0) s->by_type[ev_type_index(e->type)]++;
    if (j->which == 1)
        for (i = 0; i < 3; i++)
            if (strcmp(e->source, SRC_NAMES[i]) == 0) s->by_source[i]++;
    if (j->which == 2 && strcmp(e->type, "ALERT") == 0) {
        if (s->filtered < MAX_ALERTS) s->alerts[s->filtered++] = *e;
        else s->dropped++;
    }
    pthread_mutex_unlock(&s->lock);
}

static void *analysis_thread(void *p)
{
    Job *j = p;
    j->rc = ev_scan(j->path, analyse_cb, j, NULL);
    return NULL;
}

static int write_all(int fd, const char *p, size_t n)
{
    while (n > 0) {
        ssize_t k = write(fd, p, n);
        if (k < 0) { if (errno == EINTR) continue; return -1; }
        p += k; n -= (size_t)k;
    }
    return 0;
}

static long send_via_fifo(const char *fifo, const char *consumer, const Event *a, long n, int *cstatus)
{
    pid_t pid;
    int fd, st;
    long i, sent = 0;
    char line[MAX_LINE], tr[48];

    if (mkfifo(fifo, 0600) < 0 && errno != EEXIST) { perror("mkfifo"); return -1; }
    pid = fork();
    if (pid < 0) { perror("fork"); return -1; }
    if (pid == 0) {
        execl(consumer, consumer, fifo, (char *)NULL);
        perror("exec ipc_consumer");
        _exit(127);
    }
    fd = open(fifo, O_WRONLY);                       /* blocks until the consumer opens the read end */
    if (fd < 0) { perror("open fifo"); waitpid(pid, &st, 0); return -1; }
    for (i = 0; i < n; i++) {
        int len = ev_format(&a[i], line, sizeof line);
        if (len < 0 || write_all(fd, line, (size_t)len) < 0) { perror("write fifo"); break; }
        sent++;
    }
    snprintf(tr, sizeof tr, "#END|%ld\n", sent);
    if (write_all(fd, tr, strlen(tr)) < 0) perror("write END");
    close(fd);                                       /* EOF for the consumer */
    if (waitpid(pid, &st, 0) < 0) { perror("waitpid"); return -1; }
    *cstatus = WIFEXITED(st) ? WEXITSTATUS(st) : -1;
    unlink(fifo);
    return sent;
}

static long send_via_tcp(int port, const char *server, const char *srvlog, const Event *a, long n, int *sstatus)
{
    pid_t pid;
    int fd = -1, st, tries, rc;
    long i, acked = 0;
    char pstr[16], line[MAX_LINE], req[MAX_MSG], reply[MAX_MSG + 1];
    struct sockaddr_in addr;

    snprintf(pstr, sizeof pstr, "%d", port);
    pid = fork();
    if (pid < 0) { perror("fork"); return -1; }
    if (pid == 0) {
        execl(server, server, pstr, srvlog, "1", (char *)NULL);   /* serve exactly one connection */
        perror("exec event_server");
        _exit(127);
    }
    memset(&addr, 0, sizeof addr);
    addr.sin_family = AF_INET; addr.sin_port = htons((unsigned short)port);
    inet_pton(AF_INET, "127.0.0.1", &addr.sin_addr);
    for (tries = 0; tries < 50; tries++) {           /* server may not be listening yet */
        fd = socket(AF_INET, SOCK_STREAM, 0);
        if (fd < 0) { perror("socket"); break; }
        if (connect(fd, (struct sockaddr *)&addr, sizeof addr) == 0) break;
        close(fd); fd = -1;
        usleep(100000);
    }
    if (fd < 0) { fprintf(stderr, "could not connect to the server\n"); kill(pid, SIGTERM); waitpid(pid, &st, 0); return -1; }
    printf("[monitor] connected to server after %d retr%s\n", tries, tries == 1 ? "y" : "ies");
    for (i = 0; i < n; i++) {
        int len = ev_format(&a[i], line, sizeof line);
        if (len < 0) continue;
        line[len - 1] = '\0';                        /* drop the newline */
        snprintf(req, sizeof req, "EVENT|%s", line);
        if (send_msg(fd, req) < 0) { perror("send_msg"); break; }
        rc = recv_msg(fd, reply, sizeof reply, NULL);
        if (rc <= 0) { fprintf(stderr, "no reply (%d)\n", rc); break; }
        if (strncmp(reply, "ACK|", 4) == 0) acked++;
    }
    close(fd);                                       /* tells the server we are done */
    if (waitpid(pid, &st, 0) < 0) { perror("waitpid"); return -1; }
    *sstatus = WIFEXITED(st) ? WEXITSTATUS(st) : -1;
    return acked;
}

int main(int argc, char **argv)
{
    const char *dir = argc > 1 ? argv[1] : "work";
    long n = argc > 2 ? atol(argv[2]) : 60, i, generated = 0, persisted = 0, ipc_sent, tcp_acked, srv_lines, bad;
    int port = argc > 3 ? atoi(argv[3]) : 5060, cstatus = -1, sstatus = -1, rc;
    char log[256], fifo[256], srvlog[256];
    struct tm t = {0};
    time_t base;
    unsigned long r = 4242UL;
    pthread_t th[3];
    Job job[3];
    static Shared sh;
    Event e;

    setvbuf(stdout, NULL, _IOLBF, 0);
    signal(SIGPIPE, SIG_IGN);
    mkdir(dir, 0755);
    snprintf(log, sizeof log, "%s/campus_events.log", dir);
    snprintf(fifo, sizeof fifo, "%s/events.fifo", dir);
    snprintf(srvlog, sizeof srvlog, "%s/server_received.log", dir);
    remove(log); remove(srvlog);
    { FILE *f0 = fopen(log, "w"); if (!f0) { perror(log); return 1; } fclose(f0); }   /* log exists even with 0 events */

    /* 1-2. generate events and persist each one in the log file */
    t.tm_year = 126; t.tm_mon = 10; t.tm_mday = 5; t.tm_hour = 8;
    base = timegm(&t);
    for (i = 1; i <= n; i++) {
        r = r * 1103515245UL + 12345UL;
        e.id = (int)i;
        snprintf(e.source, sizeof e.source, "%s", SRC_NAMES[i % 3]);
        ev_make_timestamp(base + i * 37, e.timestamp);
        snprintf(e.type, sizeof e.type, "%s", EVENT_TYPES[(r >> 12) % NUM_TYPES]);
        snprintf(e.message, sizeof e.message, "campus event %ld from %s", i, e.source);
        generated++;
        if (ev_append(log, &e) == 0) persisted++;
        else perror("ev_append");
    }
    printf("[monitor] generated %ld events, persisted %ld in %s\n", generated, persisted, log);

    /* 3-4. three analysis threads, shared state protected by one mutex */
    if (pthread_mutex_init(&sh.lock, NULL) != 0) { fprintf(stderr, "mutex init failed\n"); return 1; }
    for (i = 0; i < 3; i++) {
        job[i].sh = &sh; job[i].path = log; job[i].which = (int)i; job[i].rc = -1;
        rc = pthread_create(&th[i], NULL, analysis_thread, &job[i]);
        if (rc != 0) { fprintf(stderr, "pthread_create: %s\n", strerror(rc)); return 1; }
    }
    for (i = 0; i < 3; i++) pthread_join(th[i], NULL);
    pthread_mutex_destroy(&sh.lock);
    printf("[monitor] threads joined: processed T1(types)=%ld T2(sources)=%ld T3(alert filter)=%ld\n",
           sh.processed[0], sh.processed[1], sh.processed[2]);
    printf("[monitor] by type:");
    for (i = 0; i < NUM_TYPES; i++) printf(" %s=%ld", EVENT_TYPES[i], sh.by_type[i]);
    printf("\n[monitor] by source:");
    for (i = 0; i < 3; i++) printf(" %s=%ld", SRC_NAMES[i], sh.by_source[i]);
    printf("\n[monitor] filtered ALERT events: %ld (dropped %ld)\n", sh.filtered, sh.dropped);

    /* 5. send the filtered events to a separate process through the FIFO */
    printf("[monitor] --- IPC: FIFO to ipc_consumer ---\n");
    ipc_sent = send_via_fifo(fifo, "./ipc_consumer", sh.alerts, sh.filtered, &cstatus);

    /* 6. transfer the same events to a TCP server process */
    printf("[monitor] --- TCP: client to event_server on 127.0.0.1:%d ---\n", port);
    tcp_acked = send_via_tcp(port, "./event_server", srvlog, sh.alerts, sh.filtered, &sstatus);

    /* 7. final report */
    srv_lines = ev_scan(srvlog, NULL, NULL, &bad);
    if (srv_lines < 0) { srv_lines = 0; bad = 0; }      /* server log is only created by the first ACKed event */
    printf("\n========== FINAL REPORT ==========\n");
    printf("generated events         : %ld\n", generated);
    printf("persisted in log         : %ld\n", persisted);
    printf("processed by analysis    : %ld / %ld / %ld\n", sh.processed[0], sh.processed[1], sh.processed[2]);
    printf("filtered (type ALERT)    : %ld\n", sh.filtered);
    printf("sent through FIFO        : %ld (consumer exit status %d)\n", ipc_sent, cstatus);
    printf("transmitted + ACKed (TCP): %ld (server exit status %d)\n", tcp_acked, sstatus);
    printf("records in server log    : %ld (malformed %ld)\n", srv_lines, bad);
    rc = (persisted == generated && sh.processed[0] == generated && sh.processed[1] == generated &&
          sh.processed[2] == generated && ipc_sent == sh.filtered && cstatus == 0 &&
          tcp_acked == sh.filtered && sstatus == 0 && srv_lines == sh.filtered);
    printf("consistency check        : %s\n", rc ? "PASS" : "FAIL");
    return rc ? 0 : 1;
}
